<div style="background-color:black; color:white; text-align:center; padding:10px;">
        Curs <?php echo date("2024") . "-" . (date("Y")); ?>
    </div>
</body>
</html>